package aula_6.agenda;

public class agenda {
    

        private String nome;
        private String email;
        private String celular;




    // Setter do nome
    public void setNome(String nome) {
        // nome = nome
        this.nome = nome;
    }
    public String getNome(){
        return nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getEmail() {
        return email;
    }
    public void setCelular(String celular) {
        this.celular = celular;
    }
    public String getCelular() {
        return celular;
    }

    

}
